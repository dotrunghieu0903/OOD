﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraUI
{
    //lớp lấy thông tin đang nhập 
    public static class NguoiDN 
    {
        public static string MaNV;
        public static string HoTen;
        public static string ChucVu;
    }
}

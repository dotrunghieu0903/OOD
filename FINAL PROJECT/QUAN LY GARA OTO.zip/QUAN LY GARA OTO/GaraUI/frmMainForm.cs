﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraBars;

namespace GaraUI
{
    public partial class frmMainForm : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public frmMainForm()
        {
            InitializeComponent();
        }

        private void frmMainForm_Load(object sender, EventArgs e)
        {

        }

        private void barMdiChildrenListItem1_ListItemClick(object sender, ListItemClickEventArgs e)
        {
            
        }

        private void barMdiChildrenListItem3_ListItemClick(object sender, ListItemClickEventArgs e)
        {

        }
    }
}
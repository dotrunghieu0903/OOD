﻿namespace GaraUI {
    
    
    public partial class QUAN_LY_GARA_OTODataSet {
    }
}

namespace GaraUI.QUAN_LY_GARA_OTODataSetTableAdapters {
    
    
    public partial class CT_PhieuSuaChuaTableAdapter {
    }
}

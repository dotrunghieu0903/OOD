﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraDATA.Info
{
    //Class lấy giá trị và cài đặt giá trị cho Phiếu Sửa Chữa
    public class PhieuSuaChua
    {
        public string MaSuaChua { set; get; }
        public string BienSo { set; get; }
        public string NgaySuaChua { set; get; }
        public double TongTien { set; get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraDATA.Info
{
    //Class lấy giá trị và cài đặt giá trị cho đối tượng Tiến công
    public class TienCong
    {
        public string NoiDungSuaChua { set; get; }
        public double GiaTienCong { set; get; }
    }
}

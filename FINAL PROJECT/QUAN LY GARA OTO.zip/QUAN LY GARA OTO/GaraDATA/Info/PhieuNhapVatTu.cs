﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraDATA.Info
{
    //Class lấy giá trị và cài đặt giá trị cho Phiếu Nhập Vật Tư
    public class PhieuNhapVatTu
    {
        public string MaPhieuNhap { set; get; }
        public string NgayNhapHang { set; get; }
        public string DiaDiem { set; get; }
        public string TongTien { set; get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraDATA.Info
{
    //Class lấy giá trị và cài đặt giá trị cho báo cáo tồn
    public class BaoCaoTon
    {
        public string MaVatTu { set; get; }
        public int Thang { set; get; }
        public int Nam { set; get; }
        public int TonDau { set; get; }
        public int TonCuoi { set; get; }
        public int PhatSinh { set; get; }
    }
}

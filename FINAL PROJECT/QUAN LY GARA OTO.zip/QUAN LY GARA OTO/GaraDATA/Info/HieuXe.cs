﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraDATA.Info
{
    //Class lấy giá trị và cài đặt giá trị cho Hiệu Xe
    public class HieuXe
    {
        public string TenHieuXe { set; get; }
    }
}

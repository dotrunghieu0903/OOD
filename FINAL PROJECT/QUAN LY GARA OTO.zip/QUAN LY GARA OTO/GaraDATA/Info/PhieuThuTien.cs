﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraDATA.Info
{
    //Class lấy giá trị và cài đặt giá trị cho Phiếu Thu Tiền
    public class PhieuThuTien
    {
        public string MaPhieuThuTien { set; get; }
        public string BienSo { set; get; }
        public string NgayThuTien { set; get; }
        public double SoTienThu { set; get; }
    }
}

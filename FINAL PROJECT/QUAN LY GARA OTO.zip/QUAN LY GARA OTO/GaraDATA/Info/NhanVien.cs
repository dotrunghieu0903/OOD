﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraDATA.Info
{
    //Class lấy giá trị và cài đặt giá trị cho đối tượng Nhân Viên
    public class NhanVien
    {
        public string MaNV{set;get;}
        public string HoTen { set; get; }
        public string Username { set; get; }
        public string Password { set; get; }
        public string ChucVu { set; get; }
    }
}

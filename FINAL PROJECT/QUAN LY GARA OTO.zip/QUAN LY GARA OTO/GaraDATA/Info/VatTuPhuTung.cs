﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraDATA.Info
{
    //Class lấy giá trị và cài đặt giá trị cho đối tượng Vật Tư Phụ tùng
    public class VatTuPhuTung
    {
        public string MaVatTu { set; get; }
        public int SoLuongTon { set; get; }
        public double DonGia { set; get; }
    }
}
